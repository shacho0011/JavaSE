
public class Main {
	
	public static void main(String args[]){
		ParserG p = new ParserG();
		p.parser();
	}
	
}
