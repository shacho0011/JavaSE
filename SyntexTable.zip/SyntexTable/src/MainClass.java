public class MainClass {
	public static void main(String args[]){
		
		SyntexTable synTab = new SyntexTable();
		synTab.syntexTable();
		
		//SymbolTable st = new SymbolTable();
		//st.tokenTable();
		
		//TestClass t = new TestClass();
		//t.test();
		
	}
}